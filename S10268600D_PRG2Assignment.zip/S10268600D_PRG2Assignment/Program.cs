﻿
//========================================================== 
// Student Number : S10268600D
// Student Name : Kristine Keok Jia Xuan
// Partner Name : Miridhu D/O Ellapparaja
//========================================================== 

using System;
using System.Collections.Generic;
using System.IO;
using S10268600D_PRG2Assignment;

// Lists
List<Restaurant> restaurantList = new List<Restaurant>();
List<Customer> customerList = new List<Customer>();

// Stack 
Stack<Order> refundStack = new Stack<Order>();

// Basic Feature 1 (Load restaurants.csv and fooditems.csv files)
LoadRestaurants();
LoadFoodItems();

// Load customers.csv and orders.csv files
LoadCustomers();
LoadOrders();

WelcomeMessage();

while (true)
{
    // Display the main menu options
    MainMenu();

    Console.Write("Enter your choice: ");

    // Initialise choice with invalid default value
    int choice = -1;

    try
    {
        choice = Convert.ToInt32(Console.ReadLine());
    }

    catch
    {
        // Handles non-integer inputs
        Console.WriteLine("Invalid choice. Please try again.");
        continue;   // Restart the loop and shows main menu again
    }

    // Basic feature 4 - List all orders with basic information
    if (choice == 2) 
    {
        ListAllOrders(customerList, restaurantList);
    }

    // Basic feature 6 - Process an order
    else if (choice == 4)  
    {
        ProcessOrder(customerList, restaurantList, refundStack);
    }

    // Basic feature 8 - Delete an existing order
    else if (choice == 6)
    {
        DeleteOrder(customerList, refundStack);
    }

    // Advanced feature (a) - Bulk process all pending orders for the current day
    else if (choice == 7)
    {
        BulkProcessOrders(customerList, restaurantList, refundStack);
    }
    
    // Option 0 - Exit the application
    else if (choice == 0)  
    {
        SaveQueue("queue.csv");
        SaveRefundStack();
        Console.WriteLine("Goodbye!");
        break;   // Exit while loop and end the program 
    }

    // Any number not listed above is invalid (except not implemented: feature 1/3/5.)
    else
    {
        Console.WriteLine("Option does not exist. Please try again.");
    }
}


void WelcomeMessage()
{
    Console.WriteLine("Welcome to the Gruberoo Food Delivery System");
    Console.WriteLine($"{restaurantList.Count} restaurants loaded!");
    Console.WriteLine($"{CountFoodItems()} food items loaded!");
    Console.WriteLine($"{customerList.Count} customers loaded!");
    Console.WriteLine($"{CountOrders()} orders loaded!");
}


void MainMenu()
{
    Console.WriteLine();
    Console.WriteLine("===== Gruberoo Food Delivery System =====");
    Console.WriteLine("1. List all restaurants and menu items");
    Console.WriteLine("2. List all orders");
    Console.WriteLine("3. Create a new order");
    Console.WriteLine("4. Process an order");
    Console.WriteLine("5. Modify an existing order");
    Console.WriteLine("6. Delete an existing order");
    Console.WriteLine("7. Bulk processing of pending orders");
    Console.WriteLine("0. Exit");
}


// Basic Feature 1 (Load file - restaurant.csv)
void LoadRestaurants()
{
    // Clear existing restaurant data to avoid duplicates
    restaurantList.Clear();

    string[] lines = File.ReadAllLines("restaurants.csv");

    // Start from index 1 to skip header row
    for (int i = 1; i < lines.Length; i++)
    {
        string[] parts = lines[i].Split(',');

        string id = parts[0];
        string name = parts[1];
        string email = parts[2];

        Restaurant r = new Restaurant(id, name, email);

        Menu m = new Menu("M1", "Main Menu");
        r.MenuList.Add(m);

        restaurantList.Add(r);

    }
}


// Basic Feature 1 (Load file - fooditems.csv)
void LoadFoodItems()
{
    string[] lines2 = File.ReadAllLines("fooditems.csv");

    // Start from index 1 to skip header row
    for (int i = 1; i < lines2.Length; i++)
    {
        string[] parts2 = lines2[i].Split(',');

        string restaurantId = parts2[0];
        string itemName = parts2[1];
        string itemDesc = parts2[2];
        double price = Convert.ToDouble(parts2[3]);

        FoodItem fi = new FoodItem(itemName, itemDesc, price, "");

        // Find matching restaurant using restaurant ID
        for (int j = 0; j < restaurantList.Count; j++)
        {
            if (restaurantList[j].RestaurantId == restaurantId)
            {
                // Add food item to the restaurant's menu
                restaurantList[j].MenuList[0].AddFoodItem(fi);
                break;
            }
        }
    }
}


// Basic Feature 1 (Count food items)
int CountFoodItems()
{
    int count = 0;

    // Loop through each restaurant 
    for (int i = 0; i < restaurantList.Count; i++)
    {
        count = count + restaurantList[i].MenuList[0].ItemList.Count;
    }

    return count;
}


// Load customers.csv file and create Customer object
void LoadCustomers()
{
    // Clear existing customers to avoid duplicates
    customerList.Clear();

    string[] lines = File.ReadAllLines("customers.csv");

    // Start from index 1 to skip header row
    for (int i = 1; i < lines.Length; i++)
    {
        string[] parts = lines[i].Split(',');

        string name = parts[0];
        string email = parts[1];

        Customer c = new Customer(name, email);
        customerList.Add(c);
    }
}


// Find a customer object using email
Customer FindCustomerByEmail(string email)
{
    // Loop through all customers
    for (int i = 0; i < customerList.Count; i++)
    {
        // Check if the current customer's email matches the input email
        if (customerList[i].EmailAddress == email)
        {
            return customerList[i];
        }
    }
    // If no customer with the given email exists
    return null;
}


// Find a restaurant object using restaurant ID 
Restaurant FindRestaurantById(string restaurantId)
{
    // Loop through all restaurant 
    for (int i = 0; i < restaurantList.Count; i++)
    {
        // Check if the current restaurant's ID matches the input ID
        if (restaurantList[i].RestaurantId == restaurantId)
        {
            return restaurantList[i];
        }
    }
    // If no restaurant with the given ID exists 
    return null;
}


// Load orders.csv file and create Order object 
void LoadOrders()
{
    // Clear old orders
    for (int i = 0; i < restaurantList.Count; i++)
        restaurantList[i].OrderList.Clear();

    for (int i = 0; i < customerList.Count; i++)
        customerList[i].OrderList.Clear();

    string[] lines = File.ReadAllLines("orders.csv");

    // Start from index 1 to skip the header row
    for (int i = 1; i < lines.Length; i++)
    {
 
        string[] parts = lines[i].Split(',');

        int orderId = Convert.ToInt32(parts[0]);
        string customerEmail = parts[1];
        string restaurantId = parts[2];
        string deliveryDate = parts[3];
        string deliveryTime = parts[4];
        string address = parts[5];
        double totalAmount = Convert.ToDouble(parts[7]);
        string status = parts[8];

        DateTime deliveryDateTime = Convert.ToDateTime(deliveryDate + " " + deliveryTime);

        // Create a new Order object
        Order o = new Order(orderId, deliveryDateTime, address);

        o.OrderTotal = totalAmount;
        o.OrderStatus = status;

        // Link the order to the correct customer by matching email address
        for (int c = 0; c < customerList.Count; c++)
        {
            if (customerList[c].EmailAddress == customerEmail)
            {
                customerList[c].AddOrder(o);
                break;
            }
        }

        // Link the order to the correct restaurant by matching restaurant ID
        for (int r = 0; r < restaurantList.Count; r++)
        {
            if (restaurantList[r].RestaurantId == restaurantId)
            {
                restaurantList[r].OrderList.Add(o);
                break;
            }
        }
    }
}


// Count number of orders loaded
int CountOrders()
{
    int count = 0;
    for (int i = 0; i < restaurantList.Count; i++)
    {
        count += restaurantList[i].OrderList.Count;
    }
    return count;
}


// Save refund stack 
void SaveRefundStack()
{
    // Add 1 as first line used for column header
    int lineCount = 1 + refundStack.Count;

    // Create a string array with the correct number of lines
    string[] lines = new string[lineCount];

    // Add the header row
    lines[0] = "OrderId,Status,TotalAmount,DeliveryDateTime";

    int index = 1;

    // Loop through each order in the refund stack
    foreach (Order o in refundStack)
    {
        // Store one refunded order per line
        lines[index] =
            o.OrderId + "," +
            o.OrderStatus + "," +
            o.OrderTotal.ToString("0.00") + "," +
            o.DeliveryDateTime.ToString("dd/MM/yyyy HH:mm");

        index++;
    }

    // Write all lines to stack.csv
    File.WriteAllLines("stack.csv", lines);
}


// Save queue
void SaveQueue(string fileName)
{
    // Start with 1 for the header row
    int lineCount = 1; 

    // Count how many orders exist in total
    for (int i = 0; i < restaurantList.Count; i++)
    {
        lineCount += restaurantList[i].OrderList.Count;
    }

    // Create a string array with the correct number of lines
    string[] lines = new string[lineCount];

    // Add the header row
    lines[0] = "RestaurantId,OrderId,Status,TotalAmount,DeliveryDateTime";

    int index = 1;

    // Loop through each restaurant
    for (int i = 0; i < restaurantList.Count; i++)
    {
        Restaurant r = restaurantList[i];

        // Loop through each order of the restaurant
        for (int j = 0; j < r.OrderList.Count; j++)
        {
            Order o = r.OrderList[j];

            // Store one order per line in the array
            lines[index] =
                r.RestaurantId + "," +
                o.OrderId + "," +
                o.OrderStatus + "," +
                o.OrderTotal.ToString("0.00") + "," +
                o.DeliveryDateTime.ToString("dd/MM/yyyy HH:mm");

            index++; 
        }
    }

    // Write all lines in the array to the file
    File.WriteAllLines(fileName, lines);
}


// Basic feature 4 (Sorting according to OrderId)
int CompareOrdersById(Order a, Order b)
{
    return a.OrderId.CompareTo(b.OrderId);
}


// Basic feature 4 (List all orders with basic information)
void ListAllOrders(List<Customer> customerList,
                   List<Restaurant> restaurantList)
{
    Console.WriteLine("All Orders");
    Console.WriteLine("==========");

    Console.WriteLine("{0,-11} {1,-13} {2,-16} {3,-20} {4,-8} {5}",
                      "Order ID", "Customer", "Restaurant", "Delivery Date/Time", "Amount", "Status");

    Console.WriteLine("{0,-11} {1,-13} {2,-16} {3,-20} {4,-8} {5}",
                      "--------", "----------", "-------------",
                      "------------------", "------", "---------");

    // Collect all orders from all restaurants into a list
    List<Order> orderList = new List<Order>();

    foreach (Restaurant r in restaurantList)
    {
        foreach (Order o in r.OrderList)
        {
            orderList.Add(o);
        }
    }

    // Sort orders by OrderId 
    orderList.Sort(CompareOrdersById);

    if (orderList.Count == 0)
    {
        Console.WriteLine("No orders found. Please try again.");
        return;
    }

    // Display each order with customer & restaurant name
    foreach (Order o in orderList)
    {
        string customerName = "";
        string restaurantName = "";

        // Find customer name based on which customer contains this order
        foreach (Customer c in customerList)
        {
            if (c.OrderList.Contains(o))
            {
                customerName = c.CustomerName;
                break;
            }
        }

        // Find restaurant name based on which restaurant contains this order
        foreach (Restaurant r in restaurantList)
        {
            if (r.OrderList.Contains(o))
            {
                restaurantName = r.RestaurantName;
                break;
            }
        }

        Console.WriteLine("{0,-11} {1,-13} {2,-16} {3,-20} {4,-8} {5}",
            o.OrderId,
            customerName,
            restaurantName,
            o.DeliveryDateTime.ToString("dd/MM/yyyy HH:mm"),
            "$" + o.OrderTotal.ToString("0.00"),
            o.OrderStatus);
    }
}


// Basic feature 6 (Process an order)
void ProcessOrder(List<Customer> customerList,
                  List<Restaurant> restaurantList,
                  Stack<Order> refundStack)
{
    Console.WriteLine("Process Order");
    Console.WriteLine("=============");

    Restaurant selectedRestaurant = null;

    // Keep prompting user until a valid restaurant ID is entered
    while (selectedRestaurant == null)
    {
        Console.Write("Enter Restaurant ID: ");
        string restaurantId = Console.ReadLine();

        // Validate that Restaurant ID is not empty
        if (restaurantId == "")
        {
            Console.WriteLine("Restaurant ID cannot be empty. Please try again.");
            continue;
        }

        // Search for restaurant using the entered restaurant ID
        selectedRestaurant = FindRestaurantById(restaurantId);
   

        // Restaurant ID not found
        if (selectedRestaurant == null)
        {
            Console.WriteLine("Invalid Restaurant ID. Please try again.");
        }
    }

    // Check if the selected restaurant has any orders
    if (selectedRestaurant.OrderList.Count == 0)
    {
        Console.WriteLine("No orders found for this restaurant.");
        return;
    }

    // Loop through each order belonging to the selected restaurant
    for (int i = 0; i < selectedRestaurant.OrderList.Count; i++)
    {
        Order o = selectedRestaurant.OrderList[i];

        // Find the customer who placed this order
        Customer cust = FindCustomerByOrder(customerList, o);
        string customerName = "";

        for (int c = 0; c < customerList.Count; c++)
        {
            if (customerList[c].OrderList.Contains(o))
            {
                customerName = customerList[c].CustomerName;
                break;
            }
        }

        Console.WriteLine("\nOrder " + o.OrderId);
        Console.WriteLine("Customer: " + customerName);
        Console.WriteLine("Ordered Items:");
        o.DisplayOrderedFoodItems();
        Console.WriteLine("Delivery Date/Time: " + o.DeliveryDateTime.ToString("dd/MM/yyyy HH:mm"));
        Console.WriteLine("Total Amount: $" + o.OrderTotal.ToString("0.00"));
        Console.WriteLine("Order Status: " + o.OrderStatus);
        Console.WriteLine();

        string action = "";

        // Prompt user until a valid option is entered
        while (action != "C" && action != "R" && action != "S" && action != "D")
        {
            Console.Write("[C]onfirm / [R]eject / [S]kip / [D]eliver: ");
            action = Console.ReadLine().ToUpper();
            Console.WriteLine();

            // Validate that action is not empty
            if (action == "")
            {
                Console.WriteLine("Action cannot be empty. Please enter C, R, S or D.");
            }

            else if (action != "C" && action != "R" && action != "S" && action != "D")
            {
                Console.WriteLine("Invalid action. Please enter C, R, S or D.");
            }
        }

        // Confirm (C) - change status from "Pending" to "Preparing"
        if (action == "C") 
        {
            if (o.OrderStatus == "Pending")
            {
                o.OrderStatus = "Preparing";
                Console.WriteLine("Order " + o.OrderId + " confirmed. Status: Preparing");

                // Notify the customer about order confirmation
                NotifyCustomer(cust, o);
            }

            else
            {
                Console.WriteLine("Order cannot be confirmed. Status must be Pending.");
            }
                
        }

        // Reject (R) - change status from "Pending" to "Rejected" & process refund 
        else if (action == "R")
        {
            if (o.OrderStatus == "Pending")
            {
                o.OrderStatus = "Rejected";
                refundStack.Push(o);

                Console.WriteLine("Order " + o.OrderId + " rejected. Status: Rejected.");
                Console.WriteLine("Refund initiated for Order " + o.OrderId + ".");

                // Notify the customer about rejected order 
                NotifyCustomer(cust, o);
            }

            else
            {
                Console.WriteLine("Order cannot be rejected. Status must be Pending.");
            }
        }

        // Skip (S) - No notification is sent because order status remains unchanged
        else if (action == "S")
        {
            if (o.OrderStatus == "Cancelled")
            {
                Console.WriteLine("Order " + o.OrderId + " skipped. Status: Cancelled");
            }

            else
            {
                Console.WriteLine("Order cannot be skipped. Status must be Cancelled.");
            }
        }

        // Deliver (D) - change status from "Preparing" to "Delivered"
        else if (action == "D")
        {
            if (o.OrderStatus == "Preparing")
            {
                o.OrderStatus = "Delivered";
                Console.WriteLine("Order " + o.OrderId + " delivered. Status: Delivered");

                // Notify the customer about delivery
                NotifyCustomer(cust, o);
            }

            else
            {
                Console.WriteLine("Order cannot be delivered. Status must be Preparing.");
            }   
        }
    }
}


// Basic feature 8 (Delete an existing order)
void DeleteOrder(List<Customer> customerList,
                 Stack<Order> refundStack)
{
    Console.WriteLine("Delete Order");
    Console.WriteLine("============");

    Customer selectedCustomer = null;

    // Keep prompting user until a valid customer email is entered
    while (selectedCustomer == null)
    {
        Console.Write("Enter Customer Email: ");
        string email = Console.ReadLine();

        if (email == "")
        {
            Console.WriteLine("Customer Email cannot be empty. Please try again.");
            continue;
        }

        // Search for the customer using the email address
        selectedCustomer = FindCustomerByEmail(email);

        // Email not found in customer list
        if (selectedCustomer == null)
        {
            Console.WriteLine("Customer not found. Please try again.");
        }
    }

    // Display all pending orders for the selected customer
    List<Order> pendingOrders = new List<Order>();
    Console.WriteLine("Pending Orders:");

    for (int i = 0; i < selectedCustomer.OrderList.Count; i++)
    {
        if (selectedCustomer.OrderList[i].OrderStatus == "Pending")
        {
            pendingOrders.Add(selectedCustomer.OrderList[i]);
            Console.WriteLine(selectedCustomer.OrderList[i].OrderId);
        }
    }

    // If customer has no pending orders, exit the method
    if (pendingOrders.Count == 0)
    {
        Console.WriteLine("No pending orders available.");
        return;
    }

    Order selectedOrder = null;

    // Keep prompting user until a valid Order ID is entered
    while (selectedOrder == null)
    {
        Console.Write("Enter Order ID: ");
        try
        {
            int orderId = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < pendingOrders.Count; i++)
            {
                // Search for matching order in pending orders list
                if (pendingOrders[i].OrderId == orderId)
                {
                    selectedOrder = pendingOrders[i];
                    break;
                }
            }

            // Order ID not found
            if (selectedOrder == null)
            {
                Console.WriteLine("Invalid Order ID. Please try again.");
            }
        }

        catch
        {
            // Handles non-numeric input
            Console.WriteLine("Invalid input. Please try again.");
        }
    }

    Console.WriteLine("\nCustomer: " + selectedCustomer.CustomerName);
    Console.WriteLine("Ordered Items:");
    selectedOrder.DisplayOrderedFoodItems();
    Console.WriteLine("Delivery date/time: " + selectedOrder.DeliveryDateTime.ToString("dd/MM/yyyy HH:mm"));
    Console.WriteLine("Total Amount: $" + selectedOrder.OrderTotal.ToString("0.00"));
    Console.WriteLine("Order Status: " + selectedOrder.OrderStatus);

    string confirm = "";

    // Ask user to confirm deletion (Y or N)
    while (confirm != "Y" && confirm != "N")
    {
        Console.Write("Confirm deletion? [Y/N]: ");
        confirm = Console.ReadLine().ToUpper();
        Console.WriteLine();

        if (confirm == "")
        {
            Console.WriteLine("Input cannot be empty. Please enter Y or N.");
        }

        else if (confirm != "Y" && confirm != "N")
        {
            Console.WriteLine("Invalid input. Please enter Y or N.");
        }
    }

    // If user confirms deletion
    if (confirm == "Y")
    {
        // Change order status to "Cancelled"
        selectedOrder.OrderStatus = "Cancelled";

        // Push order into refund stack for processing
        refundStack.Push(selectedOrder);

        Console.WriteLine("Order " + selectedOrder.OrderId + 
                          " cancelled. Refund of $" + selectedOrder.OrderTotal.ToString("0.00") + 
                          " processed.");

        // Notify customer of cancellation
        NotifyCustomer(selectedCustomer, selectedOrder);
    }

    else
    {
        Console.WriteLine("Deletion cancelled.");
    }
    Console.WriteLine();
}


// Advanced feature (a) - Bulk processing of unprocessed orders for a current day 
void BulkProcessOrders(List<Customer> customerList,
                       List<Restaurant> restaurantList,
                       Stack<Order> refundStack)
{
    Console.WriteLine("Bulk Process Orders");
    Console.WriteLine("===================");

    // Get current date & time
    DateTime currentTime = DateTime.Now;

    int pendingCount = 0;
    int processedCount = 0;
    int preparingCount = 0;
    int rejectedCount = 0;
    int totalOrders = 0;

    // Count total number of orders in system
    for (int i = 0; i < restaurantList.Count; i++)
    {
        totalOrders += restaurantList[i].OrderList.Count;
    }

    // Loop through each restaurant
    for (int i = 0; i < restaurantList.Count; i++)
    {
        Restaurant r = restaurantList[i];

        // Loop through each order of the restaurant
        for (int j = 0; j < r.OrderList.Count; j++)
        {
            Order o = r.OrderList[j];

            // Only process orders that are still pending
            if (o.OrderStatus == "Pending")
            {
                pendingCount++;

                // Remaining time before delivery
                TimeSpan timeLeft = o.DeliveryDateTime - currentTime;

                // Find the customer who placed the order for notification
                Customer cust = FindCustomerByOrder(customerList, o);

                if (timeLeft.TotalMinutes < 60)
                {
                    o.OrderStatus = "Rejected";
                    refundStack.Push(o);
                    rejectedCount++;

                    // Notify customer about rejection
                    NotifyCustomer(cust, o);
                }

                else
                {
                    o.OrderStatus = "Preparing";
                    preparingCount++;

                    // Notify customer that order is being prepared
                    NotifyCustomer(cust, o);
                }

                processedCount++;
            }
        }
    }

    Console.WriteLine("Pending orders found: " + pendingCount);
    Console.WriteLine("Orders processed: " + processedCount);
    Console.WriteLine("Preparing orders: " + preparingCount);
    Console.WriteLine("Rejected orders: " + rejectedCount);

    // Calculate & display percentage of orders processed
    if (totalOrders > 0)
    {
        double percentage = (processedCount * 100.0) / totalOrders;

        Console.WriteLine("Percentage processed: " +
                          percentage.ToString("0.00") + "%");
    }

    else
    {
        Console.WriteLine("No orders in system.");
    }
}


// Advanced feature (c) - Customers Notification
void NotifyCustomer(Customer customer, Order order)
{
    // Check if customer exists before sending notification
    if (customer == null)
    {
        Console.WriteLine("Notification: Customer not found for Order " + order.OrderId);
        return;
    }
    Console.WriteLine("Notification: " + customer.CustomerName +
                      ", Your Order " + order.OrderId +
                      " Status has been updated to " + order.OrderStatus + ".");
    Console.WriteLine();
}


// Advanced feature (c) - Find customer who placed a specific order
Customer FindCustomerByOrder(List<Customer> customerList,
                             Order order)
{
    // Loop through all customers in the system
    for (int i = 0; i < customerList.Count; i++)
    {
        // Check if current customer's order list contains given order
        if (customerList[i].OrderList.Contains(order))
        {
            // Return the customer if order is found
            return customerList[i];
        }
    }

    // Return null if no matching customer is found
    return null;
}