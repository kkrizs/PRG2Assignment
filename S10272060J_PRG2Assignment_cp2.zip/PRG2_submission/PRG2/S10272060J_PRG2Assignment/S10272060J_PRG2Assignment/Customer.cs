﻿
//==========================================================
// Student Number : S10272060J
// Student Name : Miridhu D/O Ellapparaja
// Partner Name : Kristine Keok Jia Xuan
//========================================================== 

using S10272060J_PRG2Assignment;
using System;
using System.Collections.Generic;

namespace S10268600D_PRG2Assignment
{
    class Customer
    {
        private string emailAddress;

        private string customerName;

        private List<Order> orderList;

        public string EmailAddress
        {
            get { return emailAddress; }
            set { emailAddress = value; }
        }

        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }

        public List<Order> OrderList
        {
            get { return orderList; }
        }

        public Customer() { }

        public Customer(string name, string email)
        {
            CustomerName = name;
            EmailAddress = email;
            orderList = new List<Order>();
        }

        public void AddOrder(Order order)
        {
            orderList.Add(order);
        }

        public bool RemoveOrder(Order order)
        {
            return orderList.Remove(order);
        }

        public void DisplayAllOrders()
        {
            if (orderList.Count == 0)
            {
                Console.WriteLine("No orders found.");
                return;
            }

            foreach (var order in orderList)
            {
                Console.WriteLine(order.ToString());
            }
        }

        public override string ToString()
        {
            return $"{CustomerName} ({EmailAddress})";
        }
    }
}
