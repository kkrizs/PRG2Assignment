﻿
//========================================================== 
// Student Number : S10268600D
// Student Name : Kristine Keok Jia Xuan
// Partner Name : Miridhu D/O Ellapparaja
//========================================================== 

//========================================================== 
// Student Number : S10272060J
// Student Name : Miridhu D/O Ellapparaja
// Partner Name : Kristine Keok Jia Xuan
//========================================================== 

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

using S10268600D_PRG2Assignment;

namespace S10272060J_PRG2Assignment
{
    class Program
    {
        const string RESTAURANTS_FILE = "restaurants.csv";
        const string FOODITEMS_FILE = "fooditems.csv";
        const string CUSTOMERS_FILE = "customers.csv";
        const string ORDERS_FILE = "orders.csv";
        const string OFFERS_FILE = "specialoffers.csv";

        const string QUEUE_OUT_FILE = "queue.csv";
        const string STACK_OUT_FILE = "stack.csv";

        static List<Restaurant> restaurants = new List<Restaurant>();
        static List<Customer> customers = new List<Customer>();

        // Quick lookup
        static Dictionary<string, Restaurant> restaurantById = new Dictionary<string, Restaurant>();
        static Dictionary<string, Customer> customerByEmail = new Dictionary<string, Customer>(StringComparer.OrdinalIgnoreCase);

        // Restaurant active order queues (Pending orders)
        static Dictionary<string, Queue<Order>> restaurantQueues = new Dictionary<string, Queue<Order>>();

        // Refund stack (Cancelled/Rejected)
        static Stack<Order> refundStack = new Stack<Order>();

        // Keep all orders (for listing, totals, etc.)
        static List<Order> allOrders = new List<Order>();

        // For new order id generation
        static int nextOrderId = 1000;

        // Advanced Feature C: Store applied special offer + discounted total (OrderId -> Offer / FinalTotal)
        static Dictionary<int, SpecialOffer> orderOfferMap = new Dictionary<int, SpecialOffer>();
        static Dictionary<int, double> orderDiscountedTotalMap = new Dictionary<int, double>();

        // Status strings (because OrderStatus is a string in the finalised Order.cs)
        const string STATUS_PENDING = "Pending";
        const string STATUS_PREPARING = "Preparing";
        const string STATUS_DELIVERED = "Delivered";
        const string STATUS_CANCELLED = "Cancelled";
        const string STATUS_REJECTED = "Rejected";
        const string STATUS_ARCHIVED = "Archived";

        static void Main(string[] args)
        {
            // Feature 1 & 2: Load startup data
            LoadRestaurants();
            LoadFoodItems();
            LoadSpecialOffers();
            LoadCustomers();
            LoadOrders();

            // Startup screen
            Console.WriteLine("Welcome to the Gruberoo Food Delivery System");
            Console.WriteLine($"{restaurants.Count} restaurants loaded!");
            Console.WriteLine($"{CountAllFoodItems()} food items loaded!");
            Console.WriteLine($"{customers.Count} customers loaded!");
            Console.WriteLine($"{allOrders.Count} orders loaded!");
            Console.WriteLine();

            // Main menu loop
            while (true)
            {
                Console.WriteLine("===== Gruberoo Food Delivery System =====");
                Console.WriteLine("1. List all restaurants and menu items");
                Console.WriteLine("2. List all orders");
                Console.WriteLine("3. Create a new order");
                Console.WriteLine("4. Process an order");
                Console.WriteLine("5. Modify an existing order");
                Console.WriteLine("6. Delete an existing order");
                Console.WriteLine("7. Bulk processing of pending orders");
                Console.WriteLine("8. Display total order amount (Delivered + Refunds + Earnings)");
                Console.WriteLine("0. Exit");
                Console.Write("Enter your choice: ");

                string choice = (Console.ReadLine() ?? "").Trim();
                Console.WriteLine();

                if (choice == "0")
                {
                    SaveQueueAndStack();
                    Console.WriteLine("Goodbye! queue.csv and stack.csv saved.");
                    break;
                }
                else if (choice == "1")
                {
                    Feature_ListRestaurantsAndMenuItems();
                }
                else if (choice == "2")
                {
                    Feature_ListAllOrders();
                }
                else if (choice == "3")
                {
                    Feature_CreateNewOrder();
                }
                else if (choice == "4")
                {
                    Feature_ProcessOrder();
                }
                else if (choice == "5")
                {
                    Feature_ModifyExistingOrder();
                }
                else if (choice == "6")
                {
                    Feature_DeleteExistingOrder();
                }
                else if (choice == "7")
                {
                    Feature_BulkProcessOrders();
                }
                else if (choice == "8")
                {
                    Feature_DisplayTotals();
                }
                else
                {
                    Console.WriteLine("Invalid choice. Please try again.\n");
                }
            }
        }

        // ==========================================================
        // Feature 1 & 2: Load files (restaurants, fooditems, customers, orders, special offers)
        // ==========================================================

        static void LoadRestaurants()
        {
            string path = ResolvePath(RESTAURANTS_FILE);
            if (!File.Exists(path))
            {
                Console.WriteLine($"ERROR: Cannot find {RESTAURANTS_FILE}. Put it in the same folder as the exe.");
                return;
            }

            using (StreamReader sr = new StreamReader(path))
            {
                string header = sr.ReadLine(); // skip header
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    string[] parts = SplitCsvLine(line);
                    if (parts.Length < 3) continue;

                    string id = parts[0].Trim();
                    string name = parts[1].Trim();
                    string email = parts[2].Trim();

                    Restaurant r = new Restaurant(id, name, email);

                    Menu m = new Menu(id + "-M1", "Main Menu");
                    r.AddMenu(m);

                    restaurants.Add(r);
                    restaurantById[id] = r;
                    restaurantQueues[id] = new Queue<Order>();
                }
            }
        }

        static void LoadFoodItems()
        {
            string path = ResolvePath(FOODITEMS_FILE);
            if (!File.Exists(path))
            {
                Console.WriteLine($"ERROR: Cannot find {FOODITEMS_FILE}.");
                return;
            }

            using (StreamReader sr = new StreamReader(path))
            {
                string header = sr.ReadLine(); // skip header
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    string[] parts = SplitCsvLine(line);
                    if (parts.Length < 4) continue;

                    string restId = parts[0].Trim();
                    string itemName = parts[1].Trim();
                    string desc = parts[2].Trim();
                    double price = ParseDouble(parts[3]);

                    if (!restaurantById.ContainsKey(restId)) continue;

                    FoodItem fi = new FoodItem(itemName, desc, price, "");

                    Restaurant r = restaurantById[restId];
                    if (r.MenuList.Count == 0)
                    {
                        r.AddMenu(new Menu(restId + "-M1", "Main Menu"));
                    }

                    r.MenuList[0].AddFoodItem(fi);
                }
            }
        }

        static void LoadSpecialOffers()
        {
            string path = ResolvePath(OFFERS_FILE);
            if (!File.Exists(path))
            {
                return;
            }

            using (StreamReader sr = new StreamReader(path))
            {
                string header = sr.ReadLine(); // skip header
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    string[] parts = SplitCsvLine(line);
                    if (parts.Length < 4) continue;

                    string restaurantName = parts[0].Trim();
                    string offerCode = parts[1].Trim();
                    string desc = parts[2].Trim();
                    string discStr = parts[3].Trim();

                    double disc = 0;
                    if (discStr != "-" && discStr != "")
                        disc = ParseDouble(discStr);

                    Restaurant matched = FindRestaurantByName(restaurantName);
                    if (matched == null) continue;

                    SpecialOffer offer = new SpecialOffer(offerCode, desc, disc);
                    matched.OfferList.Add(offer);
                }
            }
        }

        static void LoadCustomers()
        {
            string path = ResolvePath(CUSTOMERS_FILE);
            if (!File.Exists(path))
            {
                Console.WriteLine($"ERROR: Cannot find {CUSTOMERS_FILE}.");
                return;
            }

            using (StreamReader sr = new StreamReader(path))
            {
                string header = sr.ReadLine(); // skip header
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    string[] parts = SplitCsvLine(line);
                    if (parts.Length < 2) continue;

                    string name = parts[0].Trim();
                    string email = parts[1].Trim();

                    Customer c = new Customer(name, email);
                    customers.Add(c);
                    customerByEmail[email] = c;
                }
            }
        }

        static void LoadOrders()
        {
            string path = ResolvePath(ORDERS_FILE);
            if (!File.Exists(path))
            {
                Console.WriteLine($"ERROR: Cannot find {ORDERS_FILE}.");
                return;
            }

            int maxId = 1000;

            using (StreamReader sr = new StreamReader(path))
            {
                string header = sr.ReadLine(); // skip header
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    string[] parts = SplitCsvLine(line);
                    if (parts.Length < 9) continue;

                    int orderId = ParseInt(parts[0]);
                    string custEmail = parts[1].Trim();
                    string restId = parts[2].Trim();
                    string delivDateStr = parts[3].Trim();
                    string delivTimeStr = parts[4].Trim();
                    string address = parts[5].Trim();
                    string createdStr = parts[6].Trim();
                    string totalStr = parts[7].Trim(); // kept for compatibility (we still calculate from items + delivery fee)
                    string statusStr = parts[8].Trim();
                    string itemsStr = parts.Length >= 10 ? parts[9] : "";

                    if (orderId > maxId) maxId = orderId;

                    if (!restaurantById.ContainsKey(restId)) continue;
                    if (!customerByEmail.ContainsKey(custEmail)) continue;

                    DateTime deliveryDT = ParseDeliveryDateTime(delivDateStr, delivTimeStr);
                    Order o = new Order(orderId, deliveryDT, address);

                    DateTime createdDT;
                    if (DateTime.TryParseExact(createdStr, "dd/MM/yyyy HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out createdDT))
                        o.OrderDateTime = createdDT;

                    AddItemsFromItemsColumn(o, restId, itemsStr);

                    o.CalculateOrderTotal();
                    double fileTotal = ParseDouble(totalStr);

                    SetOrderStatusFromCsv(o, statusStr);

                    allOrders.Add(o);

                    Customer c = customerByEmail[custEmail];
                    c.AddOrder(o);

                    Restaurant r = restaurantById[restId];
                    r.OrderList.Add(o);

                    if (IsStatus(o.OrderStatus, STATUS_PENDING))
                        restaurantQueues[restId].Enqueue(o);

                    if (IsStatus(o.OrderStatus, STATUS_CANCELLED) || IsStatus(o.OrderStatus, STATUS_REJECTED))
                        refundStack.Push(o);
                }
            }

            nextOrderId = maxId + 1;
        }

        // ==========================================================
        // Feature 3: List all restaurants and menu items
        // ==========================================================
        static void Feature_ListRestaurantsAndMenuItems()
        {
            Console.WriteLine("All Restaurants and Menu Items");
            Console.WriteLine("==============================");

            for (int i = 0; i < restaurants.Count; i++)
            {
                Restaurant r = restaurants[i];
                Console.WriteLine($"Restaurant: {r.RestaurantName} ({r.RestaurantId})");

                for (int m = 0; m < r.MenuList.Count; m++)
                {
                    Menu menu = r.MenuList[m];
                    for (int k = 0; k < menu.ItemList.Count; k++)
                    {
                        FoodItem fi = menu.ItemList[k];
                        Console.WriteLine($" - {fi.ItemName}: {fi.ItemDesc} - ${fi.ItemPrice:0.00}");
                    }
                }
            }

            Console.WriteLine();
        }

        // ==========================================================
        // Feature 4: List all orders with basic information
        // ==========================================================
        static void Feature_ListAllOrders()
        {
            Console.WriteLine("All Orders");
            Console.WriteLine("==========");

            Console.WriteLine("{0,-11} {1,-13} {2,-16} {3,-20} {4,-8} {5}",
                              "Order ID", "Customer", "Restaurant", "Delivery Date/Time", "Amount", "Status");

            Console.WriteLine("{0,-11} {1,-13} {2,-16} {3,-20} {4,-8} {5}",
                              "--------", "----------", "-------------",
                              "------------------", "------", "---------");

            List<Order> orderList = new List<Order>();

            foreach (Restaurant r in restaurants)
            {
                foreach (Order o in r.OrderList)
                {
                    orderList.Add(o);
                }
            }

            orderList.Sort(CompareOrdersById);

            if (orderList.Count == 0)
            {
                Console.WriteLine("No orders found.\n");
                return;
            }

            foreach (Order o in orderList)
            {
                string customerName = "";
                string restaurantName = "";

                foreach (Customer c in customers)
                {
                    if (c.OrderList.Contains(o))
                    {
                        customerName = c.CustomerName;
                        break;
                    }
                }

                foreach (Restaurant r in restaurants)
                {
                    if (r.OrderList.Contains(o))
                    {
                        restaurantName = r.RestaurantName;
                        break;
                    }
                }

                double displayTotal = o.OrderTotal;
                if (orderDiscountedTotalMap.ContainsKey(o.OrderId))
                {
                    displayTotal = orderDiscountedTotalMap[o.OrderId];
                }

                Console.WriteLine("{0,-11} {1,-13} {2,-16} {3,-20} {4,-8} {5}",
                    o.OrderId,
                    customerName,
                    restaurantName,
                    o.DeliveryDateTime.ToString("dd/MM/yyyy HH:mm"),
                    "$" + displayTotal.ToString("0.00"),
                    o.OrderStatus);
            }

            Console.WriteLine();
        }

        static int CompareOrdersById(Order a, Order b)
        {
            return a.OrderId.CompareTo(b.OrderId);
        }

        // ==========================================================
        // Feature 5: Create a new order (with Advanced Feature C: Special Offer)
        // ==========================================================
        static void Feature_CreateNewOrder()
        {
            Console.WriteLine("Create New Order");
            Console.WriteLine("================");

            // 1) Customer email
            Customer c = null;
            while (c == null)
            {
                Console.Write("Enter Customer Email: ");
                string email = (Console.ReadLine() ?? "").Trim();

                if (email == "")
                {
                    Console.WriteLine("Email cannot be empty.");
                    continue;
                }

                if (!customerByEmail.ContainsKey(email))
                {
                    Console.WriteLine("Customer not found. Please enter a valid customer email.");
                    continue;
                }

                c = customerByEmail[email];
            }

            // 2) Restaurant ID
            Restaurant r = null;
            while (r == null)
            {
                Console.Write("Enter Restaurant ID: ");
                string restId = (Console.ReadLine() ?? "").Trim();

                if (restId == "")
                {
                    Console.WriteLine("Restaurant ID cannot be empty.");
                    continue;
                }

                if (!restaurantById.ContainsKey(restId))
                {
                    Console.WriteLine("Restaurant not found. Please enter a valid Restaurant ID.");
                    continue;
                }

                r = restaurantById[restId];
            }

            // 3) Delivery Date/Time
            DateTime deliveryDT = ReadValidDeliveryDateTime();

            // 4) Address
            string address = "";
            while (address == "")
            {
                Console.Write("Enter Delivery Address: ");
                address = (Console.ReadLine() ?? "").Trim();
                if (address == "") Console.WriteLine("Address cannot be empty.");
            }

            // 5) Create order object
            int orderId = nextOrderId++;
            Order o = new Order(orderId, deliveryDT, address);

            // 6) Display available items and let user choose multiple items
            List<FoodItem> available = GetAllFoodItemsOfRestaurant(r);
            if (available.Count == 0)
            {
                Console.WriteLine("This restaurant has no food items. Cannot create order.\n");
                return;
            }

            Console.WriteLine("Available Food Items:");
            for (int i = 0; i < available.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {available[i].ItemName} - ${available[i].ItemPrice:0.00}");
            }

            while (true)
            {
                int itemNum = ReadInt("Enter item number (0 to finish): ");
                if (itemNum == 0) break;

                if (itemNum < 1 || itemNum > available.Count)
                {
                    Console.WriteLine("Invalid item number. Try again.");
                    continue;
                }

                int qty = ReadInt("Enter quantity: ");
                if (qty <= 0)
                {
                    Console.WriteLine("Quantity must be > 0.");
                    continue;
                }

                FoodItem baseItem = available[itemNum - 1];
                OrderedFoodItem ofi = new OrderedFoodItem(baseItem.ItemName, baseItem.ItemDesc, baseItem.ItemPrice, "", qty);
                o.AddOrderedFoodItem(ofi);
            }

            if (o.OrderedItems.Count == 0)
            {
                Console.WriteLine("No items selected. Order cancelled.\n");
                return;
            }

            // Special request
            string addReq = ReadYesNo("Add special request? [Y/N]: ");
            if (addReq == "Y")
            {
                Console.Write("Enter special request: ");
                string reqText = Console.ReadLine() ?? "";

                for (int i = 0; i < o.OrderedItems.Count; i++)
                {
                    o.OrderedItems[i].Customise = reqText;
                }
            }

            // Calculate total and show
            double total = o.CalculateOrderTotal();

            double itemsSub = total - Order.DeliveryFee;
            Console.WriteLine($"Order Total: ${itemsSub:0.00} + ${Order.DeliveryFee:0.00} (delivery) = ${total:0.00}");

            // Advanced Feature C: Apply special offer discount (percentage-based discount)
            SpecialOffer chosenOffer = ChooseSpecialOffer(r);
            double finalTotal = total;

            if (chosenOffer != null)
            {
                double discountAmount = total * (chosenOffer.Discount / 100.0);
                finalTotal = total - discountAmount;

                Console.WriteLine($"Special Offer Applied: {chosenOffer.OfferCode} ({chosenOffer.Discount:0.##}% off)");
                Console.WriteLine($"Discount: -${discountAmount:0.00}");
                Console.WriteLine($"Final Total After Discount: ${finalTotal:0.00}");
            }

            // Payment prompt
            string pay = ReadYesNo("Proceed to payment? [Y/N]: ");
            if (pay != "Y")
            {
                Console.WriteLine("Payment not done. Order not created.\n");
                return;
            }

            string method = ReadPaymentMethod();
            PayOrder(o, method);

            // Store the applied offer and discounted total (if any)
            if (chosenOffer != null)
            {
                orderOfferMap[o.OrderId] = chosenOffer;
                orderDiscountedTotalMap[o.OrderId] = finalTotal;
            }

            // Add to restaurant queue + customer list + all orders
            string restID = r.RestaurantId;
            restaurantQueues[restID].Enqueue(o);
            r.OrderList.Add(o);
            c.AddOrder(o);
            allOrders.Add(o);

            AppendOrderToOrdersCsv(o, c.EmailAddress, restID);

            Console.WriteLine($"Order {o.OrderId} created successfully! Status: Pending\n");
        }

        // ==========================================================
        // Feature 6: Process an order (with Advanced Feature C: Custom Notifications)
        // ==========================================================
        static void Feature_ProcessOrder()
        {
            Console.WriteLine("Process Order");
            Console.WriteLine("=============");

            Restaurant selectedRestaurant = null;

            while (selectedRestaurant == null)
            {
                Console.Write("Enter Restaurant ID: ");
                string restaurantId = Console.ReadLine() ?? "";

                if (restaurantId == "")
                {
                    Console.WriteLine("Restaurant ID cannot be empty. Please try again.");
                    continue;
                }

                selectedRestaurant = FindRestaurantById(restaurantId);

                if (selectedRestaurant == null)
                {
                    Console.WriteLine("Invalid Restaurant ID. Please try again.");
                }
            }

            if (selectedRestaurant.OrderList.Count == 0)
            {
                Console.WriteLine("No orders found for this restaurant.");
                return;
            }

            for (int i = 0; i < selectedRestaurant.OrderList.Count; i++)
            {
                Order o = selectedRestaurant.OrderList[i];

                Customer cust = FindCustomerByOrder(customers, o);
                string customerName = "";

                for (int c = 0; c < customers.Count; c++)
                {
                    if (customers[c].OrderList.Contains(o))
                    {
                        customerName = customers[c].CustomerName;
                        break;
                    }
                }

                Console.WriteLine("\nOrder " + o.OrderId);
                Console.WriteLine("Customer: " + customerName);
                Console.WriteLine("Ordered Items:");
                o.DisplayOrderedFoodItems();
                Console.WriteLine("Delivery Date/Time: " + o.DeliveryDateTime.ToString("dd/MM/yyyy HH:mm"));

                double displayTotal = o.OrderTotal;
                if (orderDiscountedTotalMap.ContainsKey(o.OrderId))
                {
                    displayTotal = orderDiscountedTotalMap[o.OrderId];
                }
                Console.WriteLine("Total Amount: $" + displayTotal.ToString("0.00"));
                Console.WriteLine("Order Status: " + o.OrderStatus);
                Console.WriteLine();

                string action = "";

                while (action != "C" && action != "R" && action != "S" && action != "D")
                {
                    Console.Write("[C]onfirm / [R]eject / [S]kip / [D]eliver: ");
                    action = (Console.ReadLine() ?? "").ToUpper();
                    Console.WriteLine();

                    if (action == "")
                    {
                        Console.WriteLine("Action cannot be empty. Please enter C, R, S or D.");
                    }

                    else if (action != "C" && action != "R" && action != "S" && action != "D")
                    {
                        Console.WriteLine("Invalid action. Please enter C, R, S or D.");
                    }
                }

                // Confirm (C) - change status from "Pending" to "Preparing"
                if (action == "C")
                {
                    if (IsStatus(o.OrderStatus, STATUS_PENDING))
                    {
                        if (!o.OrderPaid) PayOrder(o, "N/A");
                        o.OrderStatus = STATUS_PREPARING;
                        Console.WriteLine("Order " + o.OrderId + " confirmed. Status: Preparing");

                        // Advanced Feature C: Notify the customer about order confirmation
                        NotifyCustomer(cust, o);
                    }

                    else
                    {
                        Console.WriteLine("Order cannot be confirmed. Status must be Pending.");
                    }

                }

                // Reject (R) - change status from "Pending" to "Rejected" & process refund 
                else if (action == "R")
                {
                    if (IsStatus(o.OrderStatus, STATUS_PENDING))
                    {
                        o.OrderStatus = STATUS_REJECTED;
                        refundStack.Push(o);

                        RemoveOrderFromQueueIfExists(selectedRestaurant.RestaurantId, o.OrderId);

                        Console.WriteLine("Order " + o.OrderId + " rejected. Status: Rejected.");
                        Console.WriteLine("Refund initiated for Order " + o.OrderId + ".");

                        // Advanced Feature C: Notify the customer about rejected order 
                        NotifyCustomer(cust, o);
                    }

                    else
                    {
                        Console.WriteLine("Order cannot be rejected. Status must be Pending.");
                    }
                }

                // Skip (S) - No notification is sent because order status remains unchanged
                else if (action == "S")
                {
                    if (IsStatus(o.OrderStatus, STATUS_CANCELLED))
                    {
                        Console.WriteLine("Order " + o.OrderId + " skipped. Status: Cancelled");
                    }

                    else
                    {
                        Console.WriteLine("Order " + o.OrderId + " skipped.");
                    }
                }

                // Deliver (D) - change status from "Preparing" to "Delivered"
                else if (action == "D")
                {
                    if (IsStatus(o.OrderStatus, STATUS_PREPARING))
                    {
                        o.OrderStatus = STATUS_DELIVERED;
                        Console.WriteLine("Order " + o.OrderId + " delivered. Status: Delivered");

                        // Advanced Feature C: Notify the customer about delivery
                        NotifyCustomer(cust, o);
                    }

                    else
                    {
                        Console.WriteLine("Order cannot be delivered. Status must be Preparing.");
                    }
                }
            }
        }

        // ==========================================================
        // Feature 7: Modify an existing order
        // ==========================================================
        static void Feature_ModifyExistingOrder()
        {
            Console.WriteLine("Modify Order");
            Console.WriteLine("============");

            Customer c = ReadValidCustomer();
            if (c == null) return;

            List<Order> pending = new List<Order>();
            for (int i = 0; i < c.OrderList.Count; i++)
            {
                if (IsStatus(c.OrderList[i].OrderStatus, STATUS_PENDING))
                    pending.Add(c.OrderList[i]);
            }

            if (pending.Count == 0)
            {
                Console.WriteLine("No pending orders found for this customer.\n");
                return;
            }

            Console.WriteLine("Pending Orders:");
            for (int i = 0; i < pending.Count; i++)
            {
                Console.WriteLine(pending[i].OrderId);
            }

            int orderId = ReadInt("Enter Order ID: ");
            Order o = FindOrderByIdInList(pending, orderId);
            if (o == null)
            {
                Console.WriteLine("Invalid Order ID.\n");
                return;
            }

            Console.WriteLine("Order Items:");
            PrintOrderItemsSimple(o);
            Console.WriteLine("Address:");
            Console.WriteLine(o.DeliveryAddress);
            Console.WriteLine("Delivery Date/Time:");
            Console.WriteLine($"{o.DeliveryDateTime:dd/M/yyyy, HH:mm}");
            Console.WriteLine();

            Console.Write("Modify: [1] Items [2] Address [3] Delivery Time: ");
            string modChoice = (Console.ReadLine() ?? "").Trim();

            double oldTotal = o.CalculateOrderTotal();

            if (modChoice == "1")
            {
                o.OrderedItems.Clear();

                Restaurant r = FindRestaurantOfOrder(o);
                if (r == null)
                {
                    Console.WriteLine("Cannot find restaurant for this order.\n");
                    return;
                }

                List<FoodItem> available = GetAllFoodItemsOfRestaurant(r);
                Console.WriteLine("Available Food Items:");
                for (int i = 0; i < available.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {available[i].ItemName} - ${available[i].ItemPrice:0.00}");
                }

                while (true)
                {
                    int itemNum = ReadInt("Enter item number (0 to finish): ");
                    if (itemNum == 0) break;

                    if (itemNum < 1 || itemNum > available.Count)
                    {
                        Console.WriteLine("Invalid item number. Try again.");
                        continue;
                    }

                    int qty = ReadInt("Enter quantity: ");
                    if (qty <= 0)
                    {
                        Console.WriteLine("Quantity must be > 0.");
                        continue;
                    }

                    FoodItem baseItem = available[itemNum - 1];
                    OrderedFoodItem ofi = new OrderedFoodItem(baseItem.ItemName, baseItem.ItemDesc, baseItem.ItemPrice, "", qty);
                    o.AddOrderedFoodItem(ofi);
                }

                if (o.OrderedItems.Count == 0)
                {
                    Console.WriteLine("No items selected. Keeping order empty is not allowed. Cancelling modification.\n");
                    return;
                }
            }
            else if (modChoice == "2")
            {
                string address = "";
                while (address == "")
                {
                    Console.Write("Enter new Address: ");
                    address = (Console.ReadLine() ?? "").Trim();
                    if (address == "") Console.WriteLine("Address cannot be empty.");
                }
                o.DeliveryAddress = address;
            }
            else if (modChoice == "3")
            {
                DateTime newTime = ReadValidTimeOnly(o.DeliveryDateTime.Date);
                o.DeliveryDateTime = newTime;
            }
            else
            {
                Console.WriteLine("Invalid modification choice.\n");
                return;
            }

            double newTotal = o.CalculateOrderTotal();

            if (newTotal > oldTotal)
            {
                Console.WriteLine($"Order total increased from ${oldTotal:0.00} to ${newTotal:0.00}.");
                string pay = ReadYesNo("Pay the difference now? [Y/N]: ");
                if (pay == "Y")
                {
                    string method = ReadPaymentMethod();
                    PayOrder(o, method);
                }
                else
                {
                    Console.WriteLine("Payment not completed. (In a real system, you should not allow this.)");
                }
            }

            // If this order had a special offer, re-apply discount after modification
            if (orderOfferMap.ContainsKey(o.OrderId))
            {
                SpecialOffer offer = orderOfferMap[o.OrderId];
                double discountAmount = newTotal * (offer.Discount / 100.0);
                double finalTotal = newTotal - discountAmount;
                orderDiscountedTotalMap[o.OrderId] = finalTotal;
            }

            Console.WriteLine($"Order {o.OrderId} updated.");

            if (orderDiscountedTotalMap.ContainsKey(o.OrderId))
            {
                double finalTotal = orderDiscountedTotalMap[o.OrderId];
                Console.WriteLine($"Order #{o.OrderId} | {o.OrderStatus} | Final Total (After Discount): ${finalTotal:0.00} | Delivery: {o.DeliveryDateTime:dd/MM/yyyy HH:mm}");
            }
            else
            {
                Console.WriteLine(o.ToString());
            }

            Console.WriteLine();
        }

        // ==========================================================
        // Feature 8: Delete an existing order (with Advanced Feature C: Custom Notifications)
        // ==========================================================
        static void Feature_DeleteExistingOrder()
        {
            Console.WriteLine("Delete Order");
            Console.WriteLine("============");

            Customer selectedCustomer = null;

            while (selectedCustomer == null)
            {
                Console.Write("Enter Customer Email: ");
                string email = Console.ReadLine() ?? "";

                if (email == "")
                {
                    Console.WriteLine("Customer Email cannot be empty. Please try again.");
                    continue;
                }

                selectedCustomer = FindCustomerByEmail(email);

                if (selectedCustomer == null)
                {
                    Console.WriteLine("Customer not found. Please try again.");
                }
            }

            List<Order> pendingOrders = new List<Order>();
            Console.WriteLine("Pending Orders:");

            for (int i = 0; i < selectedCustomer.OrderList.Count; i++)
            {
                if (IsStatus(selectedCustomer.OrderList[i].OrderStatus, STATUS_PENDING))
                {
                    pendingOrders.Add(selectedCustomer.OrderList[i]);
                    Console.WriteLine(selectedCustomer.OrderList[i].OrderId);
                }
            }

            if (pendingOrders.Count == 0)
            {
                Console.WriteLine("No pending orders available.");
                return;
            }

            Order selectedOrder = null;

            while (selectedOrder == null)
            {
                Console.Write("Enter Order ID: ");
                try
                {
                    int orderId = Convert.ToInt32(Console.ReadLine());

                    for (int i = 0; i < pendingOrders.Count; i++)
                    {
                        if (pendingOrders[i].OrderId == orderId)
                        {
                            selectedOrder = pendingOrders[i];
                            break;
                        }
                    }

                    if (selectedOrder == null)
                    {
                        Console.WriteLine("Invalid Order ID. Please try again.");
                    }
                }

                catch
                {
                    Console.WriteLine("Invalid input. Please try again.");
                }
            }

            Console.WriteLine("\nCustomer: " + selectedCustomer.CustomerName);
            Console.WriteLine("Ordered Items:");
            selectedOrder.DisplayOrderedFoodItems();
            Console.WriteLine("Delivery date/time: " + selectedOrder.DeliveryDateTime.ToString("dd/MM/yyyy HH:mm"));

            double displayTotal = selectedOrder.OrderTotal;
            if (orderDiscountedTotalMap.ContainsKey(selectedOrder.OrderId))
            {
                displayTotal = orderDiscountedTotalMap[selectedOrder.OrderId];
            }
            Console.WriteLine("Total Amount: $" + displayTotal.ToString("0.00"));
            Console.WriteLine("Order Status: " + selectedOrder.OrderStatus);

            string confirm = "";

            while (confirm != "Y" && confirm != "N")
            {
                Console.Write("Confirm deletion? [Y/N]: ");
                confirm = (Console.ReadLine() ?? "").ToUpper();
                Console.WriteLine();

                if (confirm == "")
                {
                    Console.WriteLine("Input cannot be empty. Please enter Y or N.");
                }

                else if (confirm != "Y" && confirm != "N")
                {
                    Console.WriteLine("Invalid input. Please enter Y or N.");
                }
            }

            if (confirm == "Y")
            {
                selectedOrder.OrderStatus = STATUS_CANCELLED;
                refundStack.Push(selectedOrder);

                Restaurant r = FindRestaurantOfOrder(selectedOrder);
                if (r != null)
                {
                    RemoveOrderFromQueueIfExists(r.RestaurantId, selectedOrder.OrderId);
                }

                // If order had a special offer, remove from maps (cleanup)
                if (orderOfferMap.ContainsKey(selectedOrder.OrderId)) orderOfferMap.Remove(selectedOrder.OrderId);
                if (orderDiscountedTotalMap.ContainsKey(selectedOrder.OrderId)) orderDiscountedTotalMap.Remove(selectedOrder.OrderId);

                Console.WriteLine("Order " + selectedOrder.OrderId +
                                  " cancelled. Refund of $" + displayTotal.ToString("0.00") +
                                  " processed.");

                // Advanced Feature C: Notify customer of cancellation
                NotifyCustomer(selectedCustomer, selectedOrder);
            }

            else
            {
                Console.WriteLine("Deletion cancelled.");
            }
            Console.WriteLine();
        }

        // ==========================================================
        // Advanced Feature A: Bulk processing of pending orders for current day
        // ==========================================================
        static void Feature_BulkProcessOrders()
        {
            Console.WriteLine("Bulk Process Orders");
            Console.WriteLine("===================");

            DateTime currentTime = DateTime.Now;

            int pendingCount = 0;
            int processedCount = 0;
            int preparingCount = 0;
            int rejectedCount = 0;
            int totalOrders = 0;

            for (int i = 0; i < restaurants.Count; i++)
            {
                totalOrders += restaurants[i].OrderList.Count;
            }

            for (int i = 0; i < restaurants.Count; i++)
            {
                Restaurant r = restaurants[i];

                for (int j = 0; j < r.OrderList.Count; j++)
                {
                    Order o = r.OrderList[j];

                    if (IsStatus(o.OrderStatus, STATUS_PENDING))
                    {
                        pendingCount++;

                        TimeSpan timeLeft = o.DeliveryDateTime - currentTime;

                        Customer cust = FindCustomerByOrder(customers, o);

                        if (timeLeft.TotalMinutes < 60)
                        {
                            o.OrderStatus = STATUS_REJECTED;
                            refundStack.Push(o);
                            rejectedCount++;

                            RemoveOrderFromQueueIfExists(r.RestaurantId, o.OrderId);

                            // Advanced Feature C: Notify customer about rejection
                            NotifyCustomer(cust, o);
                        }

                        else
                        {
                            if (!o.OrderPaid) PayOrder(o, "N/A");
                            o.OrderStatus = STATUS_PREPARING;
                            preparingCount++;

                            // Advanced Feature C: Notify customer that order is being prepared
                            NotifyCustomer(cust, o);
                        }

                        processedCount++;
                    }
                }
            }

            Console.WriteLine("Pending orders found: " + pendingCount);
            Console.WriteLine("Orders processed: " + processedCount);
            Console.WriteLine("Preparing orders: " + preparingCount);
            Console.WriteLine("Rejected orders: " + rejectedCount);

            if (totalOrders > 0)
            {
                double percentage = (processedCount * 100.0) / totalOrders;

                Console.WriteLine("Percentage processed: " +
                                  percentage.ToString("0.00") + "%");
            }

            else
            {
                Console.WriteLine("No orders in system.");
            }

            Console.WriteLine();
        }

        // ==========================================================
        // Advanced Feature B: Display total order amount (Delivered + Refunds + Earnings)
        // ==========================================================
        static void Feature_DisplayTotals()
        {
            Console.WriteLine("Totals by Restaurant (Delivered + Refunds)");
            Console.WriteLine("=========================================");

            double grandDelivered = 0;
            double grandRefunds = 0;

            for (int i = 0; i < restaurants.Count; i++)
            {
                Restaurant r = restaurants[i];

                double deliveredSum = 0;
                double refundSum = 0;

                for (int j = 0; j < r.OrderList.Count; j++)
                {
                    Order o = r.OrderList[j];

                    double effectiveTotal = o.CalculateOrderTotal();
                    if (orderDiscountedTotalMap.ContainsKey(o.OrderId))
                        effectiveTotal = orderDiscountedTotalMap[o.OrderId];

                    if (IsStatus(o.OrderStatus, STATUS_DELIVERED))
                    {
                        deliveredSum += (effectiveTotal - Order.DeliveryFee);
                    }
                    if (IsStatus(o.OrderStatus, STATUS_CANCELLED) || IsStatus(o.OrderStatus, STATUS_REJECTED))
                    {
                        refundSum += (effectiveTotal - Order.DeliveryFee);
                    }
                }

                grandDelivered += deliveredSum;
                grandRefunds += refundSum;

                Console.WriteLine($"Restaurant: {r.RestaurantName} ({r.RestaurantId})");
                Console.WriteLine($"  Total Delivered (less delivery fee): ${deliveredSum:0.00}");
                Console.WriteLine($"  Total Refunds (less delivery fee):   ${refundSum:0.00}");
                Console.WriteLine();
            }

            double earnings = grandDelivered - grandRefunds;

            Console.WriteLine("Overall Totals");
            Console.WriteLine("==============");
            Console.WriteLine($"Total Order Amount (Delivered, less delivery): ${grandDelivered:0.00}");
            Console.WriteLine($"Total Refunds (less delivery):                 ${grandRefunds:0.00}");
            Console.WriteLine($"Final Amount Gruberoo Earns (simple):          ${earnings:0.00}");
            Console.WriteLine();
        }

        // ==========================================================
        // Advanced Feature C: Customer Notification
        // ==========================================================
        static void NotifyCustomer(Customer customer, Order order)
        {
            if (customer == null)
            {
                Console.WriteLine("Notification: Customer not found for Order " + order.OrderId);
                return;
            }
            Console.WriteLine("Notification: " + customer.CustomerName +
                              ", Your Order " + order.OrderId +
                              " Status has been updated to " + order.OrderStatus + ".");
            Console.WriteLine();
        }

        // ==========================================================
        // Save queue.csv and stack.csv on exit
        // ==========================================================
        static void SaveQueueAndStack()
        {
            using (StreamWriter sw = new StreamWriter(QUEUE_OUT_FILE, false))
            {
                sw.WriteLine("RestaurantId,OrderId,Status,DeliveryDateTime,TotalAmount");

                foreach (var kvp in restaurantQueues)
                {
                    string restId = kvp.Key;
                    Queue<Order> q = kvp.Value;

                    Order[] arr = q.ToArray();
                    for (int i = 0; i < arr.Length; i++)
                    {
                        Order o = arr[i];

                        double effectiveTotal = o.CalculateOrderTotal();
                        if (orderDiscountedTotalMap.ContainsKey(o.OrderId))
                            effectiveTotal = orderDiscountedTotalMap[o.OrderId];

                        sw.WriteLine($"{restId},{o.OrderId},{o.OrderStatus},{o.DeliveryDateTime:dd/MM/yyyy HH:mm},{effectiveTotal:0.00}");
                    }
                }
            }

            using (StreamWriter sw = new StreamWriter(STACK_OUT_FILE, false))
            {
                sw.WriteLine("OrderId,Status,DeliveryDateTime,TotalAmount");

                Order[] arr = refundStack.ToArray();
                for (int i = 0; i < arr.Length; i++)
                {
                    Order o = arr[i];

                    double effectiveTotal = o.CalculateOrderTotal();
                    if (orderDiscountedTotalMap.ContainsKey(o.OrderId))
                        effectiveTotal = orderDiscountedTotalMap[o.OrderId];

                    sw.WriteLine($"{o.OrderId},{o.OrderStatus},{o.DeliveryDateTime:dd/MM/yyyy HH:mm},{effectiveTotal:0.00}");
                }
            }
        }

        // ==========================================================
        // Helper Functions
        // ==========================================================

        static bool IsStatus(string status, string expected)
        {
            return (status ?? "").Trim().Equals(expected, StringComparison.OrdinalIgnoreCase);
        }

        static void PayOrder(Order o, string method)
        {
            o.OrderPaid = true;
            o.OrderPaymentMethod = method;
        }

        static string ResolvePath(string filename)
        {
            if (File.Exists(filename)) return filename;

            string dataPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, filename);
            if (File.Exists(dataPath)) return dataPath;

            return filename;
        }

        static string[] SplitCsvLine(string line)
        {
            List<string> parts = new List<string>();
            bool inQuotes = false;
            string current = "";

            for (int i = 0; i < line.Length; i++)
            {
                char ch = line[i];

                if (ch == '"')
                {
                    inQuotes = !inQuotes;
                }
                else if (ch == ',' && !inQuotes)
                {
                    parts.Add(current);
                    current = "";
                }
                else
                {
                    current += ch;
                }
            }

            parts.Add(current);

            for (int i = 0; i < parts.Count; i++)
            {
                string p = parts[i].Trim();
                if (p.StartsWith("\"") && p.EndsWith("\"") && p.Length >= 2)
                    p = p.Substring(1, p.Length - 2);
                parts[i] = p;
            }

            return parts.ToArray();
        }

        static double ParseDouble(string s)
        {
            double v;
            if (!double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out v))
                return 0;
            return v;
        }

        static int ParseInt(string s)
        {
            int v;
            if (!int.TryParse(s, out v))
                return 0;
            return v;
        }

        static DateTime ParseDeliveryDateTime(string dateStr, string timeStr)
        {
            DateTime date;
            DateTime time;

            DateTime.TryParseExact(dateStr, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out date);
            DateTime.TryParseExact(timeStr, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out time);

            return new DateTime(date.Year, date.Month, date.Day, time.Hour, time.Minute, 0);
        }

        static void SetOrderStatusFromCsv(Order o, string statusStr)
        {
            string s = (statusStr ?? "").Trim();

            if (s.Equals("", StringComparison.OrdinalIgnoreCase))
            {
                o.OrderStatus = STATUS_PENDING;
                return;
            }

            // Accept common variants in the CSV and map to your string-based statuses
            if (s.Equals("Confirmed", StringComparison.OrdinalIgnoreCase))
            {
                o.OrderStatus = STATUS_PREPARING;
                if (!o.OrderPaid) PayOrder(o, "N/A");
                return;
            }

            if (s.Equals("Pending", StringComparison.OrdinalIgnoreCase))
            {
                o.OrderStatus = STATUS_PENDING;
                return;
            }

            if (s.Equals("Preparing", StringComparison.OrdinalIgnoreCase))
            {
                o.OrderStatus = STATUS_PREPARING;
                if (!o.OrderPaid) PayOrder(o, "N/A");
                return;
            }

            if (s.Equals("Delivered", StringComparison.OrdinalIgnoreCase))
            {
                o.OrderStatus = STATUS_DELIVERED;
                if (!o.OrderPaid) PayOrder(o, "N/A");
                return;
            }

            if (s.Equals("Cancelled", StringComparison.OrdinalIgnoreCase))
            {
                o.OrderStatus = STATUS_CANCELLED;
                return;
            }

            if (s.Equals("Rejected", StringComparison.OrdinalIgnoreCase))
            {
                o.OrderStatus = STATUS_REJECTED;
                return;
            }

            if (s.Equals("Archived", StringComparison.OrdinalIgnoreCase))
            {
                o.OrderStatus = STATUS_ARCHIVED;
                return;
            }

            // Default fallback
            o.OrderStatus = STATUS_PENDING;
        }

        static void AddItemsFromItemsColumn(Order o, string restId, string itemsStr)
        {
            if (string.IsNullOrWhiteSpace(itemsStr)) return;

            string[] groups = itemsStr.Split('|');

            for (int i = 0; i < groups.Length; i++)
            {
                string g = groups[i].Trim();
                if (g == "") continue;

                int commaIndex = g.LastIndexOf(',');
                if (commaIndex < 0) continue;

                string itemName = g.Substring(0, commaIndex).Trim();
                string qtyStr = g.Substring(commaIndex + 1).Trim();

                int qty = ParseInt(qtyStr);
                if (qty <= 0) qty = 1;

                FoodItem fi = FindFoodItemByName(restId, itemName);
                if (fi == null)
                {
                    fi = new FoodItem(itemName, "N/A", 0, "");
                }

                OrderedFoodItem ofi = new OrderedFoodItem(fi.ItemName, fi.ItemDesc, fi.ItemPrice, "", qty);
                o.AddOrderedFoodItem(ofi);
            }
        }

        static FoodItem FindFoodItemByName(string restId, string itemName)
        {
            if (!restaurantById.ContainsKey(restId)) return null;

            Restaurant r = restaurantById[restId];
            for (int m = 0; m < r.MenuList.Count; m++)
            {
                Menu menu = r.MenuList[m];
                for (int i = 0; i < menu.ItemList.Count; i++)
                {
                    if (menu.ItemList[i].ItemName.Equals(itemName, StringComparison.OrdinalIgnoreCase))
                        return menu.ItemList[i];
                }
            }
            return null;
        }

        static Restaurant FindRestaurantByName(string name)
        {
            for (int i = 0; i < restaurants.Count; i++)
            {
                if (restaurants[i].RestaurantName.Equals(name, StringComparison.OrdinalIgnoreCase))
                    return restaurants[i];
            }
            return null;
        }

        static Restaurant FindRestaurantById(string id)
        {
            if (restaurantById.ContainsKey(id))
                return restaurantById[id];
            return null;
        }

        static Customer FindCustomerByEmail(string email)
        {
            if (customerByEmail.ContainsKey(email))
                return customerByEmail[email];
            return null;
        }

        static Customer FindCustomerByOrder(List<Customer> customerList, Order order)
        {
            for (int i = 0; i < customerList.Count; i++)
            {
                if (customerList[i].OrderList.Contains(order))
                {
                    return customerList[i];
                }
            }
            return null;
        }

        static int CountAllFoodItems()
        {
            int total = 0;
            for (int i = 0; i < restaurants.Count; i++)
            {
                Restaurant r = restaurants[i];
                for (int m = 0; m < r.MenuList.Count; m++)
                {
                    total += r.MenuList[m].ItemList.Count;
                }
            }
            return total;
        }

        static Customer ReadValidCustomer()
        {
            while (true)
            {
                Console.Write("Enter Customer Email: ");
                string email = (Console.ReadLine() ?? "").Trim();
                if (email == "")
                {
                    Console.WriteLine("Email cannot be empty.");
                    continue;
                }
                if (!customerByEmail.ContainsKey(email))
                {
                    Console.WriteLine("Customer not found. Try again.");
                    continue;
                }
                return customerByEmail[email];
            }
        }

        static DateTime ReadValidDeliveryDateTime()
        {
            DateTime date;
            while (true)
            {
                Console.Write("Enter Delivery Date (dd/mm/yyyy): ");
                string dateStr = (Console.ReadLine() ?? "").Trim();

                if (!DateTime.TryParseExact(dateStr, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
                {
                    Console.WriteLine("Invalid date format. Please use dd/mm/yyyy.");
                    continue;
                }

                if (date.Date < DateTime.Now.Date)
                {
                    Console.WriteLine("Delivery date cannot be in the past.");
                    continue;
                }

                break;
            }

            DateTime time;
            while (true)
            {
                Console.Write("Enter Delivery Time (hh:mm): ");
                string timeStr = (Console.ReadLine() ?? "").Trim();

                if (!DateTime.TryParseExact(timeStr, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out time))
                {
                    Console.WriteLine("Invalid time format. Please use hh:mm (24-hour).");
                    continue;
                }

                break;
            }

            DateTime deliveryDT = new DateTime(date.Year, date.Month, date.Day, time.Hour, time.Minute, 0);

            if (deliveryDT < DateTime.Now)
            {
                Console.WriteLine("Delivery date/time cannot be earlier than now. Please re-enter.");
                return ReadValidDeliveryDateTime();
            }

            return deliveryDT;
        }

        static DateTime ReadValidTimeOnly(DateTime deliveryDate)
        {
            while (true)
            {
                Console.Write("Enter new Delivery Time (hh:mm): ");
                string timeStr = (Console.ReadLine() ?? "").Trim();

                DateTime time;
                bool ok =
                    DateTime.TryParseExact(timeStr, "HH:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out time) ||
                    DateTime.TryParseExact(timeStr, "H:mm", CultureInfo.InvariantCulture, DateTimeStyles.None, out time);

                if (!ok)
                {
                    Console.WriteLine("Invalid time format. Please use hh:mm (24-hour).");
                    continue;
                }

                DateTime combined = new DateTime(
                    deliveryDate.Year, deliveryDate.Month, deliveryDate.Day,
                    time.Hour, time.Minute, 0
                );

                if (deliveryDate.Date == DateTime.Now.Date && combined <= DateTime.Now)
                {
                    Console.WriteLine("New delivery time must be later than the current time (today).");
                    continue;
                }

                return combined;
            }
        }

        static int ReadInt(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string s = (Console.ReadLine() ?? "").Trim();

                int v;
                if (!int.TryParse(s, out v))
                {
                    Console.WriteLine("Invalid number. Try again.");
                    continue;
                }

                return v;
            }
        }

        static string ReadPaymentMethod()
        {
            while (true)
            {
                Console.WriteLine("Payment method:");
                Console.Write("[CC] Credit Card / [PP] PayPal / [CD] Cash on Delivery: ");
                string method = (Console.ReadLine() ?? "").Trim().ToUpper();

                if (method == "CC" || method == "PP" || method == "CD")
                    return method;

                Console.WriteLine("Invalid payment method. Try again.");
            }
        }

        static List<FoodItem> GetAllFoodItemsOfRestaurant(Restaurant r)
        {
            List<FoodItem> list = new List<FoodItem>();
            for (int m = 0; m < r.MenuList.Count; m++)
            {
                Menu menu = r.MenuList[m];
                for (int i = 0; i < menu.ItemList.Count; i++)
                    list.Add(menu.ItemList[i]);
            }
            return list;
        }

        static void PrintOrderItemsSimple(Order o)
        {
            for (int i = 0; i < o.OrderedItems.Count; i++)
            {
                OrderedFoodItem item = o.OrderedItems[i];
                Console.WriteLine($"{i + 1}. {item.ItemName} - {item.QtyOrdered}");
            }
        }

        static Order FindOrderByIdInList(List<Order> list, int id)
        {
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].OrderId == id)
                    return list[i];
            }
            return null;
        }

        static Restaurant FindRestaurantOfOrder(Order o)
        {
            for (int i = 0; i < restaurants.Count; i++)
            {
                Restaurant r = restaurants[i];
                for (int j = 0; j < r.OrderList.Count; j++)
                {
                    if (r.OrderList[j].OrderId == o.OrderId)
                        return r;
                }
            }
            return null;
        }

        static void RemoveOrderFromQueueIfExists(string restId, int orderId)
        {
            if (!restaurantQueues.ContainsKey(restId)) return;

            Queue<Order> q = restaurantQueues[restId];
            if (q.Count == 0) return;

            Queue<Order> newQ = new Queue<Order>();
            while (q.Count > 0)
            {
                Order cur = q.Dequeue();
                if (cur.OrderId != orderId)
                    newQ.Enqueue(cur);
            }

            restaurantQueues[restId] = newQ;
        }

        static void AppendOrderToOrdersCsv(Order o, string customerEmail, string restaurantId)
        {
            bool exists = File.Exists(ORDERS_FILE);
            using (StreamWriter sw = new StreamWriter(ORDERS_FILE, true))
            {
                if (!exists)
                {
                    sw.WriteLine("OrderId,CustomerEmail,RestaurantId,DeliveryDate,DeliveryTime,DeliveryAddress,CreatedDateTime,TotalAmount,Status,Items");
                }

                string deliveryDate = o.DeliveryDateTime.ToString("dd/MM/yyyy");
                string deliveryTime = o.DeliveryDateTime.ToString("HH:mm");
                string createdDT = o.OrderDateTime.ToString("dd/MM/yyyy HH:mm");
                string total = o.CalculateOrderTotal().ToString("0.00");

                string items = BuildItemsColumn(o);

                string status = o.OrderStatus.ToString();

                sw.WriteLine($"{o.OrderId},{customerEmail},{restaurantId},{deliveryDate},{deliveryTime},{EscapeCsv(o.DeliveryAddress)},{createdDT},{total},{status},\"{items}\"");
            }
        }

        static string BuildItemsColumn(Order o)
        {
            string result = "";
            for (int i = 0; i < o.OrderedItems.Count; i++)
            {
                OrderedFoodItem item = o.OrderedItems[i];
                if (i > 0) result += "|";
                result += item.ItemName + ", " + item.QtyOrdered;
            }
            return result;
        }

        static string EscapeCsv(string s)
        {
            if (s.Contains(",") || s.Contains("\""))
            {
                s = s.Replace("\"", "\"\"");
                return "\"" + s + "\"";
            }
            return s;
        }

        // ==========================================================
        // Advanced Feature C: Special Offer Helpers
        // ==========================================================

        static SpecialOffer ChooseSpecialOffer(Restaurant r)
        {
            if (r.OfferList == null || r.OfferList.Count == 0)
                return null;

            string ans = ReadYesNo("Apply special offer? [Y/N]: ");
            if (ans != "Y") return null;

            Console.WriteLine("Available Special Offers:");
            for (int i = 0; i < r.OfferList.Count; i++)
            {
                SpecialOffer offer = r.OfferList[i];

                if (offer.Discount > 0)
                    Console.WriteLine($"{i + 1}. {offer.OfferCode} - {offer.OfferDesc} ({offer.Discount:0.##}% off)");
                else
                    Console.WriteLine($"{i + 1}. {offer.OfferCode} - {offer.OfferDesc} (No % discount)");
            }

            while (true)
            {
                int choice = ReadInt("Choose offer number (0 to skip): ");
                if (choice == 0) return null;

                if (choice < 1 || choice > r.OfferList.Count)
                {
                    Console.WriteLine("Invalid choice. Try again.");
                    continue;
                }

                SpecialOffer selected = r.OfferList[choice - 1];
                if (selected.Discount <= 0)
                {
                    Console.WriteLine("This offer has no percentage discount. Please choose another offer or skip.");
                    continue;
                }

                return selected;
            }
        }

        static string ReadYesNo(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                string ans = (Console.ReadLine() ?? "").Trim().ToUpper();

                if (ans == "Y" || ans == "N")
                    return ans;

                Console.WriteLine("Invalid option. Please enter Y or N.");
            }
        }
    }
}
